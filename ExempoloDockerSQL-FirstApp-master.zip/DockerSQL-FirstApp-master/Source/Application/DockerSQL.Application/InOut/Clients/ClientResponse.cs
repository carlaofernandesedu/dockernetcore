﻿namespace DockerSQL.Application.InOut.Clients
{
    public class ClientResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
