﻿namespace DockerSQL.Application.InOut.Clients
{
    public class ClientRequest
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
